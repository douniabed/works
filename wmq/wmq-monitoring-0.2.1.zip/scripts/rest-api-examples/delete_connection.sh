#!/bin/sh

# source api functions
. ./rest_api.sh


# URI
connection_name="conn1"
uri="/rest/metadata/connections/${connection_name}"

# Delete connection
log_start "Delete connection"
delete ${uri}
log_end
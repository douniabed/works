#!/bin/sh

# source api functions
. ./rest_api.sh


# Add monitors to dashboard1
dashboard_name="d1"
uri="/rest/metadata/dashboards/${dashboard_name}/monitors"
dashboard_monitors_json_data="dashboard_monitors.json"

log_start "Add monitors to simple dashboard"
create_json ${dashboard_monitors_json_data} ${uri}
log_end


# Add monitors to dashboard2
dashboard_name2="d2"
uri2="/rest/metadata/dashboards/${dashboard_name2}/monitors"
dashboard_monitors_json_data2="dashboard_monitors2.json"

log_start "Add monitors to sender receiver dashboard"
create_json ${dashboard_monitors_json_data2} ${uri2}
log_end
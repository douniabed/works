#!/bin/sh

# source api functions
. ./rest_api.sh


# URI
dashboard_name="d1"
uri="/rest/metadata/dashboards/${dashboard_name}"
new_dashboard_json_data="update_dashboard.json"

# Update dashboard
log_start "Update dashboard"
update_json ${new_dashboard_json_data} ${uri}
log_end
#!/bin/sh

# source api functions
. ./rest_api.sh


# URI
connection_name="conn1"
uri="/rest/mqtt/data/connections/${connection_name}/channels"


# List MQTT connections
log_start "List MQTT connections"
get_json ${uri} 
log_end


log_start "List MQTT connections with clientId filter"
get_json ${uri}"?clientId=mqtt*"
log_end


log_start "List MQTT connections with channelStatus filter"
get_json ${uri}"?channelStatus=running"
log_end


log_start "List MQTT connections with channelName filter"
get_json ${uri}"?channelName=PlainText*"
log_end

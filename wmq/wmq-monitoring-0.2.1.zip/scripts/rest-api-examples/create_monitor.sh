#!/bin/sh

# source api functions
. ./rest_api.sh


# URI
connection_name="conn1"
uri="/rest/metadata/connections/${connection_name}/monitors"
monitor_json_data="monitor.json"

# create monitor
log_start "Create monitor"
create_json  ${monitor_json_data}  ${uri}
log_end
#!/bin/sh

# source api functions
. ./rest_api.sh


# URI
connection_name="conn1"
uri="/rest/metadata/connections/${connection_name}/topics"


# list all topics
log_start "List topics"
get_json ${uri}
log_end

# list local topics
log_start "List topics with type filter"
get_json ${uri}"?type=local"
log_end

# list cluster topics
log_start "List topics with type filter"
get_json ${uri}"?type=cluster"
log_end

# list local topics with name filter
log_start "List topics with type & name filter"
get_json ${uri}"?type=local&name=SYSTEM.*"
log_end
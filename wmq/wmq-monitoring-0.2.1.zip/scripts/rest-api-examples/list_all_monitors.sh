#!/bin/sh

# source api functions
. ./rest_api.sh


# URI
list_monitors_uri="/rest/metadata/monitors"


# list all monitors
log_start "List all monitors"
get_json ${list_monitors_uri}
log_end

# list with filter
log_start "List all monitors with filter"
get_json ${list_monitors_uri}"?name=m*&category=queue"
log_end
#!/bin/sh

# source api functions
. ./rest_api.sh


# URI
dashboard_name="d1"
uri="/rest/metadata/dashboards/${dashboard_name}/monitors"


# Get monitors of a dashboard
log_start "Get monitors of a dashboard"
get_json ${uri}
log_end
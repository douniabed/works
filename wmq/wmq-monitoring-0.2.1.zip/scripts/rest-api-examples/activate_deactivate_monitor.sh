#!/bin/sh

# source api functions
. ./rest_api.sh


# URI
connection_name="conn1"
monitor_name="m1"
activate_monitor_uri="/rest/metadata/connections/${connection_name}/monitors/${monitor_name}/activate"
deactivate_monitor_uri="/rest/metadata/connections/${connection_name}/monitors/${monitor_name}/deactivate"

# activate/deactivate monitor
log_start "Activate monitor"
do_action ${activate_monitor_uri}
log_end

log_start "Deactivate monitor"
do_action ${deactivate_monitor_uri}
log_end

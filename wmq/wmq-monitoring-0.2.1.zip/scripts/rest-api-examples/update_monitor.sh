#!/bin/sh

# source api functions
. ./rest_api.sh


# URI
connection_name="conn1"
uri="/rest/metadata/connections/${connection_name}/monitors"
new_monitor="update_monitor.json"
new_qmgr_monitor="update_qmgr_monitor.json"

# update monitor
monitor_name="m1"
log_start "Update monitor"
update_json ${new_monitor} ${uri}/${monitor_name}
log_end

# update QMGR monitor
log_start "Update QMGR monitor"
update_json ${new_qmgr_monitor} ${uri}/qmgr
log_end

#!/bin/sh

# source api functions
. ./rest_api.sh


# URI
uri="/rest/metadata/dashboards"
dashboard_json_data="dashboard.json"
dashboard2_json_data="dashboard2.json"

# Create dashboard
log_start "Create simple dashboard"
create_json ${dashboard_json_data} ${uri}
log_end


log_start "Create sender receiver dashboard"
create_json ${dashboard2_json_data} ${uri}
log_end
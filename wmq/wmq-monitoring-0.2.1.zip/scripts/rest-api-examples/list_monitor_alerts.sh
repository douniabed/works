#!/bin/sh

# source api functions
. ./rest_api.sh


# URI
connection_name="conn1"
monitor_name="m1"
uri="/rest/data/connections/${connection_name}/monitors/${monitor_name}/alerts"


# List alerts of a monitor
log_start "List alerts of a monitor"
get_json ${uri}
log_end

# list with filter
log_start "List alerts of a monitor with filter"
get_json ${uri}"?level=error"
log_end
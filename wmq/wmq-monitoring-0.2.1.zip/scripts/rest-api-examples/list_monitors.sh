#!/bin/sh

# source api functions
. ./rest_api.sh


# URI
connection_name="conn1"
uri="/rest/metadata/connections/${connection_name}/monitors"


# List monitors
log_start "List monitor"
get_json ${uri}
log_end

# list with filter
log_start "List monitor with filter"
get_json ${uri}"?state=active"
log_end
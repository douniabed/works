#!/bin/sh

###############################################################################
# This script provide some handy functions to call monitor RESTful APIs
#
# Note: please make sure you have curl(http://curl.haxx.se/) command available
###############################################################################

# Configurations
USER="mqadmin"
PASSOWRD="mqadmin"
HOST="localhost"
PORT=8080

CONTENT_TYPE_HEAD="Content-Type: application/json"
ACCEPT_HEAD="Accept: application/json"
API_BASE_URL="http://${HOST}:${PORT}/wmq-monitoring"



# RESTful API CRUD operations

# Create a resource (POST)
create_json()
{
json_data=$1
uri=$2
curl -i -H "${CONTENT_TYPE_HEAD}" -H "${ACCEPT_HEAD}" -X POST -u ${USER}:${PASSOWRD} -d "@${json_data}"  ${API_BASE_URL}${uri}
}

# Get a resource  (GET)
get_json()
{
uri=$1
curl -i -H "${ACCEPT_HEAD}" -X GET -u ${USER}:${PASSOWRD} ${API_BASE_URL}${uri}
}

# Update a resource (PUT)
update_json()
{
json_data=$1
uri=$2
curl -i -H "${CONTENT_TYPE_HEAD}" -H "${ACCEPT_HEAD}" -X PUT -u ${USER}:${PASSOWRD} -d "@${json_data}"  ${API_BASE_URL}${uri}
}


# Delete a resource with json data as input (DELETE)
delete_json()
{
json_data=$1
uri=$2
curl -i -H "${CONTENT_TYPE_HEAD}" -H "${ACCEPT_HEAD}" -X DELETE -u ${USER}:${PASSOWRD} -d "@${json_data}" ${API_BASE_URL}${uri}
}

# Delete a resource  (DELETE)
delete()
{
uri=$1
curl -i -H "${ACCEPT_HEAD}" -X DELETE -u ${USER}:${PASSOWRD} ${API_BASE_URL}${uri}
}

# Check if a resource available or not  (HEAD)
check()
{
uri=$1
curl -i -X HEAD -u ${USER}:${PASSOWRD} ${API_BASE_URL}${uri}
}

# Execute a action   (POST)
do_action()
{
uri=$1
curl -i -H "${ACCEPT_HEAD}" -X POST -u ${USER}:${PASSOWRD} ${API_BASE_URL}${uri}
}

# Execute a action with data  (POST)
do_action_with_data()
{
json_data=$1
uri=$2
curl -i -H "${CONTENT_TYPE_HEAD}" -H "${ACCEPT_HEAD}" -X POST -u ${USER}:${PASSOWRD} -d "@${json_data}"  ${API_BASE_URL}${uri}
}

log_start()
{
msg=$1
echo "============ ${msg} ================="
}

log_end()
{
echo ""
}




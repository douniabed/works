#!/bin/sh

# source api functions
. ./rest_api.sh


# URI
connection_name="conn1"
uri="/rest/service/connections/${connection_name}/available"

# test connection
log_start "Test connection"
check ${uri}
log_end
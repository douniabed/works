#!/bin/sh

# source api functions
. ./rest_api.sh


# URI
uri="/rest/metadata/dashboards"


# list all dashboards
log_start "List all dashboards"
get_json ${uri}
log_end
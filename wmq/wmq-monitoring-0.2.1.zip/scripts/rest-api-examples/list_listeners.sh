#!/bin/sh

# source api functions
. ./rest_api.sh


# URI
connection_name="conn1"
uri="/rest/metadata/connections/${connection_name}/listeners"


# list all listeners
log_start "List all listeners"
get_json ${uri}
log_end

# list listeners with name filter
log_start "List all listeners with name filter"
get_json ${uri}"?name=SYSTEM*"
log_end